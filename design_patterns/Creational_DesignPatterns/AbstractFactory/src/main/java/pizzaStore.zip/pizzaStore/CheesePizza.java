package pizzaStore;

import java.util.ArrayList;

public abstract class CheesePizza implements Pizza{
    protected ArrayList<String> toppings = new ArrayList<String>();
}
