package pizzaStore;

import java.util.ArrayList;

public abstract class SalamiPizza implements Pizza{
    protected ArrayList<String> toppings = new ArrayList<String>();
}
