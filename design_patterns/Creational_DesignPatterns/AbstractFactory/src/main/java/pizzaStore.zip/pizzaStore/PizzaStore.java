package pizzaStore;

public abstract class PizzaStore {
    public abstract Pizza createPizza(String type);
}
