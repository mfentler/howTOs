package pizzaStore;

public interface Pizza {
    public void setTopping();
    public void eat();
}
